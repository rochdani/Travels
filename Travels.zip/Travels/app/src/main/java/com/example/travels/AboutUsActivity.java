package com.example.travels;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class AboutUsActivity extends AppCompatActivity {
    Button LogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        LogOut = (Button)findViewById(R.id.button1);
        Intent intent = getIntent();

        LogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

                Intent intent = new Intent(AboutUsActivity.this, UserLoginActivity.class);

                startActivity(intent);

                Toast.makeText(AboutUsActivity.this, "Log Out Successfully", Toast.LENGTH_LONG).show();


            }
        });

    }
}
